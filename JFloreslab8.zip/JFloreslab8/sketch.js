let img;
let c;
let img2;

function preload(){
  img = loadImage('Flower2.png');
	
  img2 = loadImage('nature.jpg')
}

function setup() {
	createCanvas(700, 500);
  
  img.loadPixels();
  
  c = img.get(img.width / 2, img.height / 2); 
  
}

function draw() {
  background(c);
  image(img, 25, 25, mouseX * 2, 175);
	image(img2, 275, mouseY * 2, 225, 150);
	
	fill(0);
	strokeWeight(2);
	textFont('Oswald');
	textSize(32);
	text('Flower', 75, 300);
	
	fill(0, 0, 200);
	strokeWeight(1);
	textFont('Helvetica');
	textSize(32);
	text('Nature', 50, 350);
}
