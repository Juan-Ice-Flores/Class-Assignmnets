let mySound;
var mic;
let osc, playing, freq, amp;

function preload() {
  soundFormats('mp3', 'ogg');
  mySound = loadSound('Battle2.mp3');
}

function setup() {
  let cnv = createCanvas(200, 300);
  mic = new p5.AudioIn();
  mic.start();
  cnv.mousePressed(canvasPressed);
  osc = new p5.Oscillator('sine');
  
	
  capture = createCapture(VIDEO);
  capture.hide();
  
  
  ;
	
}

function draw(){
	background(220);
	text('tap here to play', 00, 160)
	
  text('tap to start', 35, 180);

  micLevel = mic.getLevel();
  let y = height - micLevel * height;
  ellipse(width/2, y, 10, 10);
	
  image(capture, 0, 0, width, width * capture.height / capture.width);
  filter(INVERT);
	
	freq = constrain(map(mouseX, 0, width, 100, 500), 100, 500);
  amp = constrain(map(mouseY, height, 0, 0, 1), 0, 1);
	
	if (playing) {
    osc.freq(freq, 0.25);
    osc.amp(amp, 0.25);
	xCord=freq;
	yCord=amp;
	} else {
		xCord = width/2;
		yCord = height/2;
  }

}

function canvasPressed() {
  mySound.play();
}

function playOscillator() {
	osc.start();
  playing = true;
}

function mouseReleased() {
  osc.amp(0, 0.5);
  playing = false;
}