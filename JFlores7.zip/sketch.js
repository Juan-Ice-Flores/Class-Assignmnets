let appleheight;
let applex = [];
let mice = [];
function setup() {
  createCanvas(400, 400);
  
  appleheight = 0
}

function draw() {
  background(173, 215, 245);
  
  for(let i = 0; i < width; i+=30){
    block(i);
  }
  
  for(let i = 340; i > 200; i-=30){
    tree(i)
  }
  leaves()
  
  for(let i = 0; i < 100; i+=99){
    if(appleheight < 120){
      apple();
    appleheight ++
    }
    else
      appleheight = 0
  }
  print(applex.length);
  mice[1] = mouseX;
  mice[0] = mouseY;
}

function block(i){
  fill(181, 101, 29);
  rect(i, 370, 30, 30);
  fill(50, 200, 50);
  rect(i, 370, 30, 5);
} 

function tree(i){
  fill(121, 67, 33);
  rect(180, i, 30, 30);
}

function leaves(){
  strokeWeight(0);
  fill(34, 139, 34);
  rect(123, 160, 145, 60);
  rect(157, 130, 75, 30);
} 

function apple(){
  applex[1] = 140
  applex[2] = 240
  push()
  translate(0, 240)
  for(let i = 1; i <= 2; i++){
  fill(200, 20, 20);
  ellipse(applex[i], appleheight, 30, 30);
  fill(0);
  rect(applex[i] - 2, appleheight - 20, 5, 7);
  }
  pop()
}